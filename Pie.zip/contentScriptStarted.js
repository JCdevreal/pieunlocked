chrome.runtime.sendMessage({name:"extension:contentScriptStarted",payload:{url:window.location.href}});
//# sourceMappingURL=contentScriptStarted.js.map